 public class UpdateRoleModel
    {
        public string? RoleId { get; set; }
        public string? NewRoleName { get; set; }
    }
